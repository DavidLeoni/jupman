from example_chal import *
import unittest

class MyTest(unittest.TestCase):
    
    def test(self):
        self.assertEqual(f(3), 3)