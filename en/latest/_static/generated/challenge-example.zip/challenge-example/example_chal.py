

def f(x):
    raise Exception('TODO IMPLEMENT ME !')
    
assert f(3) == 3

