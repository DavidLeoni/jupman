import jupman
import local


def add(x,y):   
    
    return x + y
    

def sub(x,y):
    return help_func(x,y) 


# stripped stuff is not present in exercises
def help_func(x,y):
    return x - y






# everything after next comment will be discarded

# write here

def f(x):
    return x + 1